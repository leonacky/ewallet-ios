#import <Flutter/Flutter.h>

@interface VpbEwalletFlutterPlugin : NSObject<FlutterPlugin>
@end
