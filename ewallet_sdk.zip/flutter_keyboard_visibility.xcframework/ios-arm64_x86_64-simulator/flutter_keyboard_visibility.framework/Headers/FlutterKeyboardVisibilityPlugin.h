#import <Flutter/Flutter.h>

@interface FlutterKeyboardVisibilityPlugin : NSObject<FlutterPlugin>
@end
